// admin-v2.js removed: admin UI scripts are no longer present.
