import React from 'react';
export default function Cart(){
  return (<div className="container"><h2>Cart</h2><p>Cart UI placeholder. Checkout to test payments.</p><a className="btn" href="/checkout">Checkout</a></div>);
}
