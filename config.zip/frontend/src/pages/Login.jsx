import React from 'react';
export default function Login(){ return (<div className="container"><h2>Login</h2><p>Use backend /api/auth for login/register.</p></div>); }
