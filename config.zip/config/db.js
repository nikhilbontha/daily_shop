const mongoose = require('mongoose');
require('dotenv').config();

const connectDB = async () => {
  // Use environment variable when provided, otherwise fall back to local MongoDB
  const DEFAULT_LOCAL_URI = 'mongodb://localhost:27017/my_proj';

  const mongoUri = process.env.MONGO_URI || DEFAULT_LOCAL_URI;
  try {
    await mongoose.connect(mongoUri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    const which = mongoUri.includes('localhost') ? 'local MongoDB' : 'MongoDB Atlas';
    console.log(`✅ Connected to ${which}`);
  } catch (err) {
    console.error('❌ MongoDB Connection Error:', err.message || err);
    process.exit(1); // Stop server if DB fails
  }
};

module.exports = connectDB;
